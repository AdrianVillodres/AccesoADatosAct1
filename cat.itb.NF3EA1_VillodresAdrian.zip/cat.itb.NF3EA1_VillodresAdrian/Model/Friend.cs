﻿using System;

namespace UF3_test.model

{
    [Serializable]
    public class Friend
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}

